#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function ###### if migrating for Python 3, please, delete this line
import sys
from pymongo import MongoClient
from collections import OrderedDict
from datetime import datetime
#
# pttcs2mongo.py ç
# Storage of PTTCS (ProteinToTotalConectionsSorted) results to MongoDB.
# 20210105: Gilberto da Silva
#
# >>>>>> Please, use Python 2.7 <<<<<<
#
# Parameters
# 1. Input file name
# 2. Logical title of input file
#
# Input: CSV file (Comma separated fields or comma separated values)
# Three columns:
# 1. Protein accession number (UniprotKB)
# 2. Genesymbol (HUGO)
# 3. Connection numbers: Number of connection of a protein with its neighbors in the interactome
# The 1rst line is skipped because it is reserved to column titles.
# 
# Output: document within the pttcs collection galaxyData bank with the following struture
# patientID: <Input file title>
# geneArray: array de triplets with three field from the input file:
#     uniprotKB
#     genesymbol
#     connections
#
saida  = open (sys.argv[1], 'w')
client = MongoClient ('mongodb+srv://jorge:vk388nii@cluster0.tirpz.mongodb.net/jorge?retryWrites=true&w=majority')
db     = client.galaxyData
for i in range (2, len (sys.argv), 2):
  fisico = open (sys.argv[i], 'r') # , 'utf-8')
  logico = sys.argv[i+1]
  doc    = OrderedDict ()
  doc ['patientId'] = logico
  fisico.readline () # ignora a primeira linha
  geneArray = []
  linha  = fisico.readline ()
  while linha:
    linha = linha. strip ('\n')
    if linha == '':
      break
    tripla = linha. split (',')
    aGene  = OrderedDict ()
    aGene ['uniprotKB']   = tripla[0]
    aGene ['genesymbol']  = tripla[1]
    aGene ['connections'] = tripla [2]
    geneArray.append (aGene)
    linha = fisico.readline ()
  fisico.close ()  
  doc ['geneArray'] = geneArray
  tstmp = datetime.now()
  doc ['timestamp'] = tstmp
  result = db.pttcs.insert_one (doc)
  if result.acknowledged:
    saida.write ('#' + str (tstmp) + ': Document for ' + logico + ' was loaded successfully on Mongodb')
  else:
    saida.write ('#' + str (tstmp) + ': Document for ' + logico + ' was not successfully loaded on Mongodb')
saida.close ()
