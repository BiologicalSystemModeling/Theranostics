#!/usr/bin/perl

# SubRedeConstruction.pl
# Now, SRC.pl
# 20190909
# Gilberto da Silva ad Nicolas Carels

#perl ArestasStringToNumber.pl intact-miclusterC1_cat_C2.srt.cl.txt intact-micluster2col_simpl.txt intact-miclusterC1_cat_C2.srt.cl.subint
#This program takes a uniprot ID list (sub-list of nodes) and extract the completly connected subnetwork from the whole interactome. 

# Parâmetros
# ARGV[0] Input file name: Up-regulated genes
# ARGV[1] Input file name: Complete interactome
# ARGV[2] Input file name: Sub-interactome
#
$input = shift;#subnode list
$input2 = shift;#interactome
$output = shift;#subinteractome

#Node file
open (READ, "$input");
$line  = <READ>; # 1st line: Column titles      t1,t2,   (ignored)
$line2 = <READ>; # 2nd line: p-value            pp,vv,   (reserved)
$line3 = <READ>; # 3rd line: critical value     cc,vv,   (reserved)
$line4 = <READ>; # 4th line: Original file name nn,,     (reserved)
while ($line = <READ>) {
   chop $line;
   push(@tab,$line); #filling node table
}
close READ;

#Edge file
open (READ2, "$input2");
while ($line = <READ2>) {
   chop $line;
   push(@tab2,$line); #filling edge table
}
close READ2;

#Cleaning interactome table by comparing with the node table
for(my $i=0; $i<=$#tab2; $i++){ #printing node table
  ($acc1=$1, $acc2=$2) if($tab2[$i]=~/(\S+)\s(\S+)/); #read edge names
  if(!(grep(/$acc1/,@tab) && grep(/$acc2/,@tab))){ #checking for the prence of nodes 1 & 2 in the node table
     $tab2[$i]=0; #if both nodes of the interactome edge are present in the node table, the edge is kept
  }
}
@tab2=grep(/(\S+\s\S+)/,@tab2);# eliminating "0" values

#Cleaning node table
for(my $i=0; $i<=$#tab; $i++){ #scanning back node table for nodes. If not present they become "0"
  $tab[$i]=0 if(!(grep(/$tab[$i]/,@tab2))); #reseting node when not present in the interactome
}
@tab=grep(/(\D+)/,@tab);# eliminating "0" values

#Cleaning interactome table for redundancy
@tab2=sort @tab2;
for(my $i=0; $i<=$#tab2; $i++){
  $tab2[$i]=0 if($tab2[$i+1] eq $tab2[$i]);
}
@tab2=grep(/(\S+\s\S+)/,@tab2);# eliminating "0" values

#subinteractome printing
open (CAC, ">$output");  # opening node file
print CAC $line2;
print CAC $line3;
print CAC $line4;
for(my $i=0; $i<=$#tab2; $i++){ #printing node table
   my $res=$tab2[$i];
   print CAC "$tab2[$i]\n";
}
close CAC;

