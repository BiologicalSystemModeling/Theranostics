#!/usr/bin/perl

# Entropia.pl
# Nicolas Carels
# Now, ETP.pl
# Entropy calculation
# Outputs file with results of intermediary calculations of total entropy
#
# 20191019
# Gilberto da Silva
#
# Parameters
# 0: title of the output file.
# 1: title of the first input file.
# 2: prefix to identify the first file.
# 3: title of the second input file.
# 4: prefix to identify the second file.
#. . .
# 2n-1: title of the nth input file.
# 2n: prefix to identify the nth file
#
use strict;
my $output;
my $line;

sub processpair {
    my $arqe = $_[0];
    my $prfx = $_[1];
    my $pval; #p-value sent from previous step (SRC)
    my $critval; #Critical value sent from previous step (SRC) 
    my $input;
    my @tab;
    my $node;
    my $cnx;
    my @cnxlst;
    my @serie;
    my $key;
    my %cnt;
    my $concat;
    my @res;
    my $sum = 0;
    my $i;
    my $entrptot;
    my $cat;
    my $prob;
    my $freq;
    my $logar;
    my $entrp;

    # Input file with a unique list representing all genes considered: 
    # the 1st column is for genes
    # the 2nd column is for connexions 
    open ($input, "<", $arqe) or die $arqe . ": " . $!;
    $pval = <$input>; #p-value sent from previous step
    chop $pval;
    $critval = <$input>; #Critical value sent from previous step (SRC)
    chop $critval;
    while ($line = <$input>) {
        chop $line;
        push (@tab, $line); #filling edge table
        }
    close $input;

    for (my $i = 0; $i <= $#tab; $i ++) {
        ($node = $1, $cnx = $2) if ($tab [$i] =~ /(\S+)\s(\S+)/ || $tab [$i] =~ /(\S+)\,(\S+)/ || $tab [$i] =~ /(\S+)\t(\S+)/);
        push(@cnxlst, $cnx);
    }

    @cnxlst = sort { $a <=> $b } @cnxlst;

    for ($i = 0; $i <= $cnxlst [$#cnxlst]; $i ++) { 
        push(@serie,$i);
        }

    my $count = 0; 
    for ($i = 0; $i <= $#cnxlst; $i ++) {
        if ($cnxlst [$i] eq $cnxlst [$i + 1]) {
    	    $count ++;
 	    }
 	if ($cnxlst [$i] ne $cnxlst [$i + 1]) {
     	    $count ++;
            $key = "$cnxlst[$i]";
            $cnt {$key} = $count;
            $count = 0;
            }
        }

    for (my $i = 1; $i <= $#serie; $i ++) {
      $concat = "$i $cnt{$i}";
      push(@res, $concat);
    }

    for(my $i = 1; $i <= $#serie; $i ++) {
        $sum =$sum + $cnt{$i} if ($cnt {$i}); 
        }
    $entrptot = 0;
    for ($i = 0; $i < $#serie; $i ++) {
        ($cat = $1, $freq = $2) if ($res [$i] =~ /(\S+)\s(\S*)/);
        $prob = $freq / $sum if ($sum);
        $logar = (log ($prob)/log (2)) if($prob);
        $entrp = $prob * $logar;
        $entrptot = $entrptot + $entrp;
        $res [$i] = $res [$i];
        }
        $entrptot =- $entrptot;
        print $output "File $prfx; $pval; $critval; Total_entropy_tumor $entrptot\n";
    } ### processpair end

my $arqs  = $ARGV[0];
open ($output, ">", $arqs) or die;                               
for (my $inx = 1; $inx <= ($#ARGV - 1); $inx +=2) {
    processpair ($ARGV[$inx], $ARGV[$inx+1]);
    }
close ($output);

