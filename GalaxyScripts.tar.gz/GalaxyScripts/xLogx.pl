# script of log transformation. Both transforms promote differential expression curve flattening LogNorm (more) or Log2 (less). To be used after DEGL
# Nicolas Carels and Gilberto da Silva
$input  = shift;
$output = shift;
$nomext  = shift;
$nomext2 =$1 if($nomext=~/^\S+\_(\S+)\./);

my $acc;
my $dat;
my $ln;
my $line;
my $sign;


open (ECR, ">$output");
print ECR "id,$nomext2,\n";
open (READ, "<$input");#<
while ($line = <READ>) {
  $ln=0;
  ($acc=$1, $sign=$2, $dat=$3) if($line=~/^(\S+)\,(\-{0,1})(\d+\.\d+)$/);
  ($acc=$1, $sign=$2, $dat=$3) if($line=~/^(\S+)\,(\-{0,1})(\d+)$/);
  ($acc=$1, $sign=$2, $dat=$3) if($line=~/^(\S+)\t(\-{0,1})(\d+\.\d+)$/);
  ($acc=$1, $sign=$2, $dat=$3) if($line=~/^(\S+)\t(\-{0,1})(\d+)$/);
#  $ln=(log(log($dat+1)/log(1.1)+1)/log(1.1))*20*$dat; #(log(log x+1)+1)*x*20 #LogNorm
  $ln=(log($dat+1)/log(2))*$dat; #(log2(x+1))*x #Log2
  $ln=$sign.$ln;
  print ECR "$acc,$ln\n" if($dat);
}
close READ;
close ECR;
