#
# PTTCS.pl
# Original name: ProteinToTotalCnxSrtd.pl
# Nicolas Carels
# 20200217
#
# Adapted by Gilberto da Silva for Galaxy
# 20200217
# 
# Two input files
# 1. List of up-regulated genes
# 2. List of genes interactome proteíns with connection data
#
# Output file
# 1. List of up-regulated genes with their corresponding conection number by decreasing order 
#
$input = shift;#list of upregulated genes
$input2 = shift;#Sequence list of protein genes from the interactome with connection data
$output = shift;#list of upregulated genes with their total number of connections
open (ECR, ">$output");
open (READ, "$input");
$line = <READ>;
chop $line;
print ECR "$line\n";  # Column title
$line = <READ>;
chop $line;
print ECR "$line\n";  # p-value
$line = <READ>;
chop $line;
print ECR "$line\n"; # critical value
while ($line = <READ>) {
  $acc = $1 if ($line =~ /^(\S+)\,\d+/ || $line =~ /^(\S+)\,\d+.\d+/);
  push(@tab1,$acc);
  }
close READ;

open (READ, "$input2");
while ($line = <READ>) {
  chop $line;
  push(@tab2,$line) if($line=~/^>/);
  }
close READ;

foreach my $cell (@tab1){
  foreach my $cell2 (@tab2){
    (my $acc2=$1,my $gene=$2,my $cnx=$3) if($cell2=~/^>(\S+)\s(\S+)\s(\d+)/);
    if($cell eq $acc2){
      my $compo=$acc2.",".$gene.",".$cnx;
      $hash{$compo}=$cnx;
      }
    }
  }
my @tab3 = sort { $hash{$b} <=> $hash{$a} } keys %hash;

print ECR "UniprotKB,GeneSymbol,Connections\n";
foreach my $cell (@tab3){
  print ECR "$cell\n";
  }
close ECR;


