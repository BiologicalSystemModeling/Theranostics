# UTagCountExpNormG.pl
# The script does the RPKM normalization according to: (1000,000,000/total_tag_count)*(CDS_tag_count/CDS_size)
# arquivos
# arq1: input (acc_UniprotKB, sz);
# arq2: input (acc_GDC, tag_count);
# arqs: ouput   (acc_UniprotKB, tag_norm);

# Gilberto da Silva and Nicolas Carels

$arq1   = shift;  # Corresponds to the GDC file of tag-counts ("*.htseq.counts")
$arq1t = $arq1 . '.tmp';

$arq2   = shift;  # Two column file
                  # the 1st column contains the access numbers of the UniprotKB sequences listed in the InteratomeSeq 
                  # the 2nd contains the size of these sequences
$arq2t  = $arq2 . '.tmp';
#$preff  = shift;  # preffix, title of tag_count column. Typically, 'tumoral' or 'control'


#Output
$arqs   = shift;  # File of tag count normalized according to the format: acession_number Normalized_tag_count

#Open the pipe for generating the output file
open (ECR, ">$arqs");
#close ECR;
#open (ECR, ">>$arqs");

# Reading and file ordination
# Ordinate tab1 por (acc1 crescente);
# https://stackoverflow.com/questions/3200801/how-can-i-call-a-shell-command-in-my-perl-script
# https://stackoverflow.com/questions/9986515/what-is-the-difference-between-sort-k1-file-txt-and-sort-k1-1-file-txt

open (TMP0, "<$arq1");
  $title = <TMP0>;
close TMP0;

!system("sort -k1,1 $arq1 > $arq1t"); # This line could be deleted if this input file is sorted ones for all; 
                                      # but the user could forget to classify it in case of updating. 
                                      # Thus, it is perhaps better to keep it.

# ler arq1 de tamanho de sequencias para tab1;
open (TMP0, "<$arq1t");

while ($line = <TMP0>) {
  chop $line;
  push (@tab1, $line) if($line!~/(uniprot)/);
}
close TMP0;
!system("rm $arq1t");

#print ECR "@tab1\n";##########

!system("sort -k1,1 $arq2 > $arq2t");

open (TMP0, "<$arq2t");# arquivo GDC de tag counts
while ($line = <TMP0>) {
  chop $line;
  push (@tab2, $line);
}
close TMP0;
!system ("rm $arq2t");

#print ECR "@tab2\n";#############

# merge
$acc1x = 0;
$acc2x = 0;
$fim1 = 0; # 0 stands for 'false'
$fim2 = 0;
$count  = 0;
$countot = 0;
$tag_cnt  = 0;
$sz=0;

while (not ($fim1 or $fim2)) {
  @xpto1 = split (/\t/, $tab1 [$acc1x]) if($tab1 [$acc1x]=~/\t/);
  @xpto1 = split (/,/, $tab1 [$acc1x]) if($tab1 [$acc1x]=~/,/);
  @xpto2 = split (/ /,  $tab2 [$acc2x]);
  $acc1  = $xpto1 [0];
  $tag_cnt  = $xpto1 [1];
  $acc2  = $xpto2 [0];
  $sz    = $xpto2 [1];
  if ($acc1 eq $acc2) {
    $count=$tag_cnt;#
    if ($acc2x < $#tab2) {
      $acc2x ++;
      }
    else {
      $fim2 = 1;
      }
    }
  elsif ($acc1 lt $acc2) { #
    push (@data, "$acc1" . ',' . "$sz" . ',' . "$count");
    $uprqrtl{$acc1}=$count;
    $countot = $countot + $count;
    $count   = 0;
    if ($acc1x < $#tab1) {
      $acc1x ++;
      }
    else {
      $fim1 = 1;
      }
    }
  else { # Means: acc1 > acc2
    if ($acc2x < $#tab2) {
      $acc2x ++;
      }
    else {
      $fim2 = 1;
      }
    }
  }

if (not $fim1) {
  push (@data, "$acc1" . ',' . "$sz" . ',' . "$count");
  $uprqrtl{$acc1}=$count;
  $countot = $countot + $count;
  while (not $fim1) {
    if ($acc1x < $#tab1) {
      $acc1x ++;
      @xpto1 = split (/ /,  $tab1 [$acc1x]);
      $acc1  = $xpto1 [0];
      $sz    = $xpto1 [1];
      push(@data, "$acc1" . ',' . "$sz" . ',' ."0");
      }
    else {
      $fim1 = 1;
      }
    }
  }

$count=0;

print ECR "$title";  
############################################ RPKMupper #####################################################
for (my $i = 0; $i <= $#data; $i++) {
  ($acc1, $sz, $count) = split (/,/, $data[$i]);
  $norm = ($count / ($countot-($countot*0.95))) * (1000000000 / $sz) if ($countot != 0 && $sz != 0); #formula do RPKMupper
print ECR "$acc1,$norm\n";
}
close ECR;

