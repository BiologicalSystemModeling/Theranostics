#
# CVC.py
#
# 20200610 - Gilberto da Silva and Nicolas Carels
# Script for critical value calculation for the selection of up-regulated genes
#
# 20200404 - Gilberto da Silva and Nicolas Carels
# Preserves the original name of the TCGA/GDC file for future reference.
#
#import matplotlib.pyplot as plt
#import matplotlib.mlab as mlab
import scipy.stats
from scipy.stats import norm
import numpy as np
import math 
import sys
import re
from math import log
from scipy.optimize import curve_fit
import random

# CriticalValueCalculator.py
# CVC.py
#
# A partir de um p-value fornecido por parametro, calcula o valor critico da distribuicao 
# de valores de expressao diferencial, supostamente distribuidos ao longo de uma curva
# normal. Tambem, grava os genes selecionados por terem niveis de expressao maiores do 
# que o valor do ponto critico calculado.

# From a p-value provided in parameter, the scripts calculates the corresponding critical value
# of up-regulated genes. The up-regulated genes have higher differential expression levels than
# the critical point correponding to the p-value given in parameter.
#
# There are three parameters:
# 1. Input file name
# 2. p-value to consider for the calculation of the critical value (larger than 0.9500).
#    Caution: use a dot as decimal separator!
# 3. Output file name.
#
# Input file:
# 1. Table of differentially expressed genes.
# A two column file in *.csv format
# Column 1. Gene identification;
# Column 2. Differential expression value.
# The first row is a row of column headings.
# The second line is the title of the original TCGA file.
# The data content is given from the third line onwards.
#
# Output file
# 1. Table of up-regulated genes whos differentail expression is larger than the critical value.
#    Two columns in *.csv format.
#    Column 1: Gene identification;
#    Column 2: Differential expression.
#    The first three lines are reserved.
#    The first row is a row of column headings, that is, "gene_id, diff".
#    The second line informs the "p-value" value received in parameter:
#    "p-value, <p-value>,".
#    The third line informs the critical point value calculated by this
#    program: "critval, <critval>,".
#    The fourth line contains the title of the original TCGA file.
#    The data content is given from the fifth line onwards.
#==================== Data elaboration ====================
# Read data from file
data = []
with open (sys.argv[1]) as fd:
    line = fd.readline () # The three first lines are for headings and are skiped
    line = fd.readline () # 
    line = fd.readline ()
    while line:
        data.append (line.rstrip ('\n'))
        line = fd.readline ()
fd.close ()
x3 = np.array (data)

# p-value (>0.95) passed in parameter
p = float (sys.argv [2]) 

x2=[]
for i in x3:
    a=re.split("\,",i)
    x2.append(float(a[1]))

x1 = sorted(x2)
x=[]
limite = int (sys.argv [3])
for i in x1:
    if i >= -limite and i <= +limite:
          x.append(i)
    
# Calculation of histogram variables
sz = np.size(x) #size of the array
ntvl = math.sqrt(sz) #number of interval or bins
first_edge, last_edge = min(x), max(x) # The leftmost and rightmost bin edges
range = last_edge - first_edge #data interval
width = range/ntvl #with of intervals or bins
#bin_edges = np.linspace(start=first_edge, stop=last_edge, num=intvl + 1, endpoint=True)
#'np.linspace' returns evenly spaced numbers over a specified interval.
bn = range/width

# Find mean and st. dev.
mean = np.mean(x)
variance = np.var(x)
sigma = np.sqrt(variance)

# Calculates pdf and cdf
#x = np.linspace(min(data), max(data), 100) 
pdf = norm.pdf(x, mean, sigma)
cdf = norm.cdf(x, mean, sigma)

# Finds critical value
crits = np.where(abs(np.round(cdf, 4) >= p))[0]
crit = x[crits[0]]

# Writes the critical value in a file
fd = open (sys.argv [1])
fp = open (sys.argv [4], 'w')
line = fd.readline ()                  # input  line #1: column titles
fp.write (str (line))                  # output line #1: column titles
line = 'p-value,' + str (p) + ',\n'    # p-value received from previous
fp.write (str (line))                  # output line #2 p-value, <value>
line = 'critval,' + str (crit) + ',\n' # critval calculated here
fp.write (str (line))                  # output line #3 critval, <value>
line = fd.readline ()                  # input  line #2: original TCGA file
fp.write (str (line))                  # output line #4 original TCGA file
line = fd.readline ()                  # input  line #3: data
while line:
    a = re.split ('\,', line)
    if float (a[1]) >= crit:
        fp.write (str (line))
    line = fd.readline ()
fd.close
fp.close

