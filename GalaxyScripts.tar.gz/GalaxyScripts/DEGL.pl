use strict;
#
# 20200404 - Gilberto da Silva and Nicolas Carels
# Inclusion of the external name of the TCGA file in the second line of the output file.
# Variabel $nomext
#
# DiffExpGenList.pl
# Nicolas Carels - 20200109.
#
# Adaptation
# Novo nome: DEGL.pl
# Gilberto da Silva - 20200110
#
# This program computes a differential expressions from tmor and control RNA-seq, which is needed for critical value calculation 
#
# Both input files (tumor and control) are in CSV format (fields separated by TAB and decimal by DOTs)
# In both files, the first field is the gene identification (UniprotKB).
# The second field is the level of gene expression.
# Same genes exist in both files, in the same order;
# what the program does is to calculate the expression difference
# "expression values of the first" - "expression values of the second",
# preserving the gene identification on the output.
#
# To find up-regulated genes in tumors, the CONTROL (TCGA = 11A) is considered as FORWARD and the TUMORAL file (TCGA = 01A) 
# is considered as REVERSE.
# A similar convention must be adopted for other files
# that are used, as follows: Both file pairs
# referring to a single patient must have titles formed
# with a prefix common to both and distinct suffixes that allow
# identify which is the tumor sample file and which is the control sample file.
# In a TCGA case, for example, the common prefix is: TCGA-BR-6454-
# and the tumor file suffix: 11A-01R-1802-13.txt.
# The suffix of the control sample file is: 01A-01R-1802-13.txt.
# The title of the output file, in this example, should be dev_TCGA-BR-6454.csv
# "dev" from differential expression values
#
# The output is a 2 column CSV file (fields separated by COMMA and decimal by DOTs).
# The first field is for the gene identification.
# The second field is for the differential expression (tumor minus control).
# The first line is for field titles: "gene_id, diff".

# Parâmetros
# 1. Título do arquivo de entrada com os níveis de expressão de genes 
#    na amostra TUMORAL.
# 2. Título do arquivo de entrada com os níveis de expressão de genes 
#    na amostra de CONTROLE.
# 3. Título do arquivo de saída.
#
# Parameters
# 1. Title of the input file with gene expression levels in the TUMORAL sample.
# 2. Title of the input file with gene expression levels in the CONTROL sample.
# 3. Title of the output file.

my $input1;
my $input2;
my $output;
my $nomext;
my $line;
my @tab1;
my @tab2;
my %mal;
my @difexp;
my @diff;
my $sepcamp; # Field separator: tab or comma
my $sepdeci; # Decimal separator: dot or comma
# if $sepcamp = $sepdeci ==> erro, execution stoped
# $sepcamp and $sepdeci need to be set for both files.
# In any cases, the outputfile will be given with $sepcamp = comma and $sepdeci = dot
my @fields;

$input1  = shift;  ### First parameter 
# Two-column list of RNA-seq #1 (the one in which up-regulated genes 
# will be looked for => tumor)
$input2  = shift;  ### segundo  parâmetro 
# Two-column list of RNA-seq #2 (the control one => stroma)
$output  = shift;  ### 3rd parameter
$nomext  = shift;  ### 4th parameter 
$sepcamp = shift;  ### 5th parameter
$sepdeci = shift;  ### 6th parameter
if (not ($sepcamp eq "tab" or $sepcamp eq "vrg")) {
    print $sepcamp . ": Field separator: tab or comma\n";
    print "Execution stoped\n";
    exit ()
    }
if (not ($sepdeci eq "pnt" or $sepdeci eq "vrg")) {
    print $sepdeci . ": Decimal separator: dot or comma\n";
    print "Execution stoped\n";
    exit ()
    }
if ($sepcamp eq $sepdeci) {
    print "The field separator must be different from the decimal separator\n";
    print "Execution stoped\n";
    exit ()
    }

# Tables of expression values
if ($sepcamp eq "vrg" and $sepdeci eq "pnt") { # Does not need any modification; it is already in csv format
    open (READ, "<$input1");
    $line = <READ>;
    while ($line = <READ>) {
        $line =~ s/\R//g;#"\R" matches any Unicode newline sequence, i.e., "\n" ou "\r\n"
        push(@tab1,$line) #Table of malign expressions
        }
    close READ;
    open (READ, "<$input2>");
    $line = <READ>;
    while ($line = <READ>) {
        $line =~ s/\R//g;
        push(@tab2,$line) #Table of control expressions
        }
    close READ;
    }

elsif ($sepcamp eq "tab" and $sepdeci eq "pnt") { # When the field separator is tab
    open (READ, "<$input1");
    $line = <READ>;
    while ($line = <READ>) {
        $line =~ s/\R//g;
        $line =~ s/\t/,/g;
        push(@tab1,$line); #Table of malign expressions
	}
    close READ;
    open (READ, "<$input2");
    $line = <READ>; ### Skipping the first line
    while ($line = <READ>) {
        $line =~ s/\R//g;
        $line =~ s/\t/,/g;
        push(@tab2,$line); #Table of control expressions
        }
    close READ;
    }

else { # $sepcamp eq "tab" and $sepdeci eq "vrg"
# Changing comma per dot and tab per comma (in this order)
    open (READ, "<$input1");
    $line = <READ>;
    while ($line = <READ>) {
        $line =~ s/\R//g;
        $line =~ s/,/./g;
	$line =~ s/\t/,/g;
	push(@tab1,$line); #Table of malign expressions
        }
    close READ;
    open (READ, "<$input2");
    $line = <READ>; ### Skipping the first line
    while ($line = <READ>) {
        $line =~ s/\R//g;
        $line =~ s/,/./g;
	$line =~ s/\t/,/g;
	push(@tab2,$line); #Table of control expressions
        }
    close READ;
    }

open (ECR, ">$output");
print ECR "$nomext,,\n";     # 
print ECR "gene_id,diff,\n"; #
for (my $i=0; $i<=$#tab1; $i++) {
    @fields = split (",", $tab1 [$i]);
    $mal {$fields [0]} = $fields [1]; # Hash for selection of up-regulated genes
    }
for (my $i=0; $i<=$#tab2; $i++) {
    @fields = split (",", $tab2 [$i]);
    if (exists $mal {$fields [0]}) {
        print ECR "$fields[0]," . ($mal {$fields[0]} - $fields[1]) . "\n";
        }
    }
close ECR;                                                            
