# UTagCountExpNormG.pl
# This one is the UNSTRANDED version.
# This script serve to assess the gene expression from a BLASTx file according to the command line:
# nohup blastall -p blastx -i ./File_seq -d ./InteratomeSeq -v 1 -b 1 -m8 -e 0.0001 -o File_output &
# The script does the RPKM normalization according to: (1000,000,000/total_tag_count)*(CDS_tag_count/CDS_size)
# A tag is counted only if the best alignment is at least 85% identical to the reference over at least 
# 50 bp (BLASTx) of the reference (UniprotKB)
# Version du script acelerada pelo Gilberto
# arquivos
# arq1: entrada (acc1, sz);
# arq2: entrada (acc2, id, start, stop);
# arqs: sa�da   (acc3, sz, count, norm);

# not useful in Galaxy environment
# $d = localtime ();
# print "TagCountExpNormG.pl inicio $d \n";

$arq1   = shift;  # Two column file
                # the 1st column contains the access numbers of the reference file of BLAST (here InteratomeSeq); 
                # the 2nd contains the size of these sequences
#$arq1t  = $arq1 . '.tmp';
#$arq1t  = $$ . $arq1 . '.tmp'; ### 20201214 Gilberto
$arq1t  =  $arq1 . $$ .'.tmp'; # $$ captures the PID (process identifier) which gives a specificity to the name that cannot be confused by Galaxy when it tries to remove the file later on

$arq2   = shift;  # Corresponds to the BLAST output file
$arq2t1 =  $arq2 . $$ . '.tmp1';### 20201214 Gilberto
$arq2t2 =  $arq2 . $$ . '.tmp2';### 20201214 Gilberto

#$preff  = shift;  # preffix, title of tag_count column. Typically, 'tumoral' or 'control'

$arqs   = shift;  # File of tag count according to the format: acession_number coding_sequence_size tag_count

#Open the pipe for generating the output file
open (ECR, ">$arqs");
#close ECR;
#open (ECR, ">>$arqs");

# Reading and ordinting files
# Ordinate tab1 per increasing acc1
#https://stackoverflow.com/questions/3200801/how-can-i-call-a-shell-command-in-my-perl-script
#https://stackoverflow.com/questions/9986515/what-is-the-difference-between-sort-k1-file-txt-and-sort-k1-1-file-txt

!system("sort -k1,1 $arq1 > $arq1t"); # This line could be deleted if this input file is sorted ones for all; 
                                      # but the user could forget to classify it in case of updating. 
                                      # Thus, it is perhaps better to keep it.
				      # "-k1,1" says to sort on the portion of the line that starts at the beginning
				      # of the first field and ends at the end of the first field.

# Read arq1 for tab1;
open (TMP0, "<$arq1t");
while ($line = <TMP0>) {
  chop $line;
  push (@tab1, $line);
  }
close TMP0;
!system("rm $arq1t");

open (TMP0, "<$arq2");
open (TMP1, ">$arq2t1");
#close TMP1;
#open (TMP1, ">>$arq2t1");
while ($line = <TMP0>) {
  @xpto  = split (/\t/, $line);
  $acc2  = $xpto [1];
  $id    = $xpto [2];
  $lngt  = $xpto [3]; #$absolute similarity length in amino acid
  if ($id >= 85 && $lngt >= 17) { 
    # A difference of 50 bp is equivalente to select dif>=17 (amino acids or 51 bp), 
    # given in absolute value in column 4 (-k4,4). 
    # However, filtering out on bp (k4) allows to eliminate similarities involving the wrong strand 
    # while filtering out on amino acid (k3) would allow similarities from both strands. 
    # Considering k3 or k4 is critical for gene expression consistancy and will depend on the 
    # sequencing chemistry (Illumina, Ion, or BGI). This option, must be chosen by the user.   
    print TMP1 $line;
    }
  }
close TMP0;
close TMP1;

# 7 ordenar tab2 por (acc2 crescente);
#https://unix.stackexchange.com/questions/183524/unix-sort-by-multiple-columns
#http://www.pangloss.com/wiki/Blast
!system("sort -k2,2 -k3,3 -k4,4 $arq2t1 > $arq2t2");
# k2=subject (the gene targeted), k3=identity, k4=identity_size

open (TMP2, "<$arq2t2");
while ($line = <TMP2>) {
  push (@tab2, $line);
  }
close TMP2;
!system ("rm $arq2t1");
!system ("rm $arq2t2");

# merge
$acc1x = 0;
$acc2x = 0;
$fim1 = 0; # 0 stands for 'false'
$fim2 = 0;
$count  = 0;
$countot = 0;
%uprqrtl;
while (not ($fim1 or $fim2)) {
  @xpto1 = split (/ /,  $tab1 [$acc1x]);
  @xpto2 = split (/\t/, $tab2 [$acc2x]);
  $acc1  = $xpto1 [0];
  $sz    = $xpto1 [1];
  $acc2  = $xpto2 [1];
  $id    = $xpto2 [2];
  $start = $xpto2 [6];
  $stop  = $xpto2 [7];
  if ($acc1 eq $acc2) {
    $count ++;
    if ($acc2x < $#tab2) {
      $acc2x ++;
      }
    else {
      $fim2 = 1;
      }
    }
  elsif ($acc1 lt $acc2) {
    push (@data, "$acc1" . ',' . "$sz" . ',' . "$count");
    $uprqrtl{$acc1}=$count;
    $countot = $countot + $count;
    $count   = 0;
    if ($acc1x < $#tab1) {
      $acc1x ++;
      }
    else {
      $fim1 = 1;
      }
    }
  else { # Mens acc1 > acc2
    if ($acc2x < $#tab2) {
      $acc2x ++;
      }
    else {
      $fim2 = 1;
      }
    }
  }

if (not $fim1) {
  push (@data, "$acc1" . ',' . "$sz" . ',' . "$count");
  $uprqrtl{$acc1}=$count;
  $countot = $countot + $count;
  while (not $fim1) {
    if ($acc1x < $#tab1) {
      $acc1x ++;
      @xpto1 = split (/ /,  $tab1 [$acc1x]);
      $acc1  = $xpto1 [0];
      $sz    = $xpto1 [1];
      push(@data, "$acc1" . ',' . "$sz" . ',' ."0");
      }
    else {
      $fim1 = 1;
      }
    }
  }

print ECR "access,$arq2\n";  

############################################ RPKMupper #####################################################
for (my $i = 0; $i <= $#data; $i++) {
  ($acc1, $sz, $count) = split (/,/, $data [$i]);
  $norm = ($count / ($countot-($countot*0.95))) * (1000000000 / $sz) if ($countot != 0 && $sz != 0);
  print ECR "$acc1,$norm\n";
}
close ECR;

