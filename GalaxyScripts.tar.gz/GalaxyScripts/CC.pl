#!/usr/bin/perl

# CountConex.pl
# Now, CC.pl
# 20191016
# Gilberto da Silva and Nicolas Carels

# This program counts the connections of each gene of the sub-interactome
# of up-regulated genes as an intermediate step to calculate entropy.

# Input file with two interaction columns representing a subnetwork of
# up-regulated genes: the 1st column is for the sorted genes and
# the 2nd for the neighbors, i.e., connexion number.
#
# Output file with results of intermediary calculations of total entropy

my $arqe  = $ARGV[0];
my $arqs  = $ARGV[1];                   
my $input;                               
my $output;

open ($input,  "<", $arqe);
open ($output, ">", $arqs);
$line = <$input>;  # p-value
@fields = split (/,/, $line);
print $output "$fields[0],$fields[1]\n";
$line = <$input>;  # critval
@fields = split (/,/, $line);
print $output "$fields[0],$fields[1]\n";
$line = <$input>;  # f-name
@fields = split (/,/, $line);
print $output "$fields[0],$fields[1]\n";
while ($line = <$input>) {
    chop $line;
    (my $gene=$1, my $gene2=$2) if($line=~/(\S+)\s(\S+)/ || $line=~/(\S+)\t(\S+)/);
    push(@genlst,$gene); #filling the total list of genes
}
close ($input);
$count=1;
for(my $i=0; $i<=$#genlst; $i++){
  if($genlst[$i] eq $genlst[$i-1]){
     $count++;
     $mem=$genlst[$i];
  }
  if(($genlst[$i] ne $genlst[$i-1]) && $genlst[$i-1]){
     print $output "$mem,$count\n" if($mem);
     $count++;
     $count=1;
     $mem=$genlst[$i];
  }
  if($genlst[$i] eq $genlst[$#genlst]){
     print $output "$mem,$count\n";
  }
}
close $output;

