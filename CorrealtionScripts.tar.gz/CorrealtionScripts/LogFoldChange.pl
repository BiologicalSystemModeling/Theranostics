#use strict;
#
# 20200404 - Nicolas Carels
# Inclusion of the external name of the TCGA file in the second line of the output file.
# Variable $namext
#
# DiffExpGenList.pl
# Nicolas - 20200109.
#
# Adaptations
# New name: DEGL.pl
# Gilberto - 20200110
#
# This program calculates a list of differential expression values
# to calculate the expression cutoff where to consider genes as up-regulated
#
# The input is two CSV files (fields separated by TAB and DOT decimal separator)
# of gene expression levels, both with two fields and identical layout.
# The first field is the gene identification (UniprotKB).
# The second field is the gene expression level.
# The same genes exist in both files, in the same order;
# what the program does is calculate the difference
# "expression values of the first" - "expression values of the second",
# preserving the gene identification in the output.
#
# To make sense of the rest of the workflow,
# The first file contains gene expression levels
# in the patient's TUMOR sample. In TCGA files this is indicated
# by particle 11A in the file title.
# The second file contains gene expression levels
# in the CONTROL sample (healthy tissue) of the patient. In TCGA files,
# this is indicated by the 01A particle in the file title.
#
# A similar convention must be adopted for other files
# that will be used, as follows: Every two files
# referring to a single patient must have titles formed
# with a prefix common to both and different suffixes, which allow
# identify which file is the tumor sample and which is the control sample.
# In a TCGA case, for example, we have
# common prefix: TCGA-BR-6454-
# tumor sample file suffix: 11A-01R-1802-13.txt
# control sample file suffix: 01A-01R-1802-13.txt
# the title of the output file, in this example, should be dev_TCGA-BR-6454.csv
# "dev" of differential expression values

# The output file is a legitimate CSV file (fields separated by
# <comma> and decimal divider <point>), with two fields.
# The first field is gene identification.
# The second field is the difference of gene expression values,
# tumor less control.
# The first line is field titles, literally "gene_id,diff".
#
# Parameters
# 1. Title of the input file with gene expression levels
# in the TUMOR sample.
# 2. Title of the input file with gene expression levels
# in the CONTROL sample.
# 3. Output file title.
#

my $input1;
my $input2;
my $output;
my $nomext;
my $line;
my @tab1;
my @tab2;
my %mal;
my @difexp;
my @diff;
my $sepcamp; # field separator, tab or vrg
my $sepdeci; # decimal separator, nt or vrg
# if $sepcamp = $sepdeci ==> it's wrong, it can't be executed
# $sepcamp and $sepdeci must be valid for both files
# either way, the output file will be written with
# #sepcamp = vrg and $sepdeci = pnt
my @fields;
my $ratioex1ex2; #exp level ratio of tumor over control
my $logfold; #log fold 2 (ln) of $ratioex1ex2

$input1  = shift;  ### first paremeter 
# Two-column list of RNA-seq1 (the one in which up-regulated genes 
# will be looked for => tumor)
$input2  = shift;  ### second  parameter 
# Two-column list of RNA-seq2 (the control one => stroma)
$output  = shift;  ### tird parameter
$nomext  = shift;  ### forth parameter 
$sepcamp = shift;  ### fifth parameter
$sepdeci = shift;  ### sexth  parameter
if (not ($sepcamp eq "tab" or $sepcamp eq "vrg")) {
    print $sepcamp . ": Field seperator must be tab ou vrg\n";
    print "Execution canceled\n";
    exit ()
    }
if (not ($sepdeci eq "pnt" or $sepdeci eq "vrg")) {
    print $sepdeci . ": Decimal separator must be pnt ou vrg\n";
    print "Execution canceled\n";
    exit ()
    }
if ($sepcamp eq $sepdeci) {
    print "Field separator must be diferent from decimal separator\n";
    print "Execution canceled\n";
    exit ()
    }

# Tables of expression values
if ($sepcamp eq "vrg" and $sepdeci eq "pnt") { # não precisa trocar nada, já está .csv
    open (READ, "<$input1");
    $line = <READ>;
    while ($line = <READ>) {
        $line =~ s/\R//g;#"\R" matches any Unicode newline sequence, i.e., "\n" ou "\r\n"
        $line =~ s/\t/,/g;
        push(@tab1,$line) #Table of malign expressions
        }
    close READ;
    open (READ, "<$input2>");
    $line = <READ>;
    while ($line = <READ>) {
        $line =~ s/\R//g;#\R = \r\n do Windows https://stackoverflow.com/questions/30647164/perl-r-regex-strip-windows-newline-character
        $line =~ s/\t/,/g;
        push(@tab2,$line) #Table of control expressions
        }
    close READ;
    }

elsif ($sepcamp eq "tab" and $sepdeci eq "pnt") { # só precisa trocar tab por vrg
    open (READ, "<$input1");
    $line = <READ>;
    while ($line = <READ>) {
        $line =~ s/\R//g;
        $line =~ s/\t/\,/g;
        push(@tab1,$line); #Table of malign expressions
	}
    close READ;
    open (READ, "<$input2");
    $line = <READ>; ### desprezo a primeira linha
    while ($line = <READ>) {
        $line =~ s/\R//g;
        $line =~ s/\t/\,/g;
        push(@tab2,$line); #Table of control expressions
        }
    close READ;
    }

else { # $sepcamp eq "tab" and $sepdeci eq "vrg"
# precisa trocar vrg por pnt e tab por vrg (nessa ordem)
    open (READ, "<$input1");
    $line = <READ>;
    while ($line = <READ>) {
        $line =~ s/\R//g;
        $line =~ s/,/./g;
	$line =~ s/\t/,/g;
	push(@tab1,$line); #Table of malign expressions
        }
    close READ;
    open (READ, "<$input2");
    $line = <READ>; ### despise the first line
    while ($line = <READ>) {
        $line =~ s/\R//g;
        $line =~ s/,/./g;
	$line =~ s/\t/,/g;
	push(@tab2,$line); #Table of control expressions
        }
    close READ;
    }

open (ECR, ">$output");
print ECR "$nomext,,\n";     # 
print ECR "gene_id,diff,\n"; # 
#print "@tab2\n";
for (my $i=0; $i<=$#tab1; $i++) {
    @fields = split (",", $tab1 [$i]);
#    (my $acc1=$1, my $exp1=$2) if($tab1[$i]=~/,/);
#    (my $acc1=$1, my $exp1=$2) if($tab1[$i]=~/(\S+)\s(\S+)/ || $tab1[$i]=~/(\S+)\t(\S+)/);
    $mal {$fields [0]} = $fields [1]; # Hash for selection of up-regulated genes
    }
for (my $i=0; $i<=$#tab2; $i++) {
    @fields = split (",", $tab2 [$i]);
#    (my $acc2=$1, my $exp2=$2) if($tab2[$i]=~/,/);
    if (exists $mal {$fields [0]}) {
         $ratioex1ex2 = $mal {$fields[0]} / $fields[1] if($fields[1]!=0);#Log(0) = impossible -> must be avoided
#         $ratioex1ex2 = $mal {$fields[0]} / $fields[1] if($fields[1]>10);############# RPKM filter
         if($ratioex1ex2!=0){
              $logfold = log($ratioex1ex2) / log(2);
              print ECR "$fields[0]," . $logfold . "\n" if($logfold>=1);############## Log2FoldChange filter
           }
        }
    }
close ECR;                                                            
